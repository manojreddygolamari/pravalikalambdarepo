import boto3
import json
from pprint import pprint

region = 'ap-south-1'

#creating the client for the ec2 service
ec2 = boto3.client('ec2', region_name=region)

#creating the client for the SES service
ses=boto3.client('ses')

def lambda_handler(event, context):
    #collect the instance ids in empty list
    instance_ids = []
    #Filters=[{'Name': 'tag:Department', 'Values': ['Prod']}]
    instances_full_details =ec2.describe_instances(Filters=[{'Name': 'tag:Department', 'Values': ['Prod']}])['Reservations']
    for instance_detail in instances_full_details:
        group_instances = instance_detail['Instances']
        for instance in group_instances:
            instance_id = instance['InstanceId']
           # instance_ids.append(instance_id)
            print("Instance Id's ::",instance_id)
            state=instance["State"]['Name']
            
            #instance details
            instanceID=instance_id
            instanceImageId=instance['ImageId']
            instancetype=instance['InstanceType']
            instanceState=state
            instanceAZ=instance['Placement']['AvailabilityZone']
            instanceKeyName=instance['KeyName']
            instancePrivateIP=instance['PrivateIpAddress']
            instancePublicIP=instance['PublicIpAddress']
            instanceVpcId=instance['VpcId']
            instanceSubnetId=instance['SubnetId']
            instanceStateTransitionReason=instance['StateTransitionReason']
            print("***************" * 10)
            print(instanceID)
            print(instanceImageId)
            print(instancetype)
            print(instanceState)
            print(instanceAZ)
            print(instanceKeyName)
            print(instancePrivateIP)
            print(instancePublicIP)
            print(instanceVpcId)
            print(instanceSubnetId)
            print(instanceStateTransitionReason)
            
            if state in ['running']:
                print("prod instance is {}".format(instanceState))
                
                #source Email
                source_Email='balafrancismanojreddy@gmail.com'
                
                #destination Email
                destination_Email='francismanojreddy@gmail.com'
                
                #cc Email
                cc_Email='balafrancismanojreddy@gmail.com'
                
                #subject of the Email
                Subject ='Prod EC2 Instance change to {}'.format(instanceState)
                
                #body of the email
                Body='''
                        <br>
                        Hello Team, 
                        <br>
                        <br>
                        This Email is regarding the Prod EC2 Instance <b>Instance ID :: {iid}.</b> 
                        State change to {ist}.
                        <br>
                        <br>
                        Below are the details. 
                        <br>
                        Please take a look at high priority in order to avoid the service interruption.
                        <br>
                        <b>Instance ID</b>: {iid} <br>
                        <b>Instance ImageId</b>: {im} <br>
                        <b>Instance Type</b>: {it} <br>
                        <b>Instance State</b>: {ist} <br>
                        <b>Instance AZ</b>: {az} <br>
                        <b>Instance Keypair</b>: {kp} <br>
                        <b>Instance PrivateIP</b>: {priIp} <br>
                        <b>Instance PublicIP</b>: {pubIp} <br>
                        <b>Instance VpcId</b>: {vpc} <br>
                        <b>Instance SubnetId</b>: {sub} <br>
                        <b>Instance StateTransitionReason</b>: {statereason} <br>
                        
                        <br>
                        <br>
                        <br>
                        <b>
                        Thanks & Regards,
                        <br>
                        G B F Manoj Reddy
                        </b>
                    '''.format(iid=instanceID,im=instanceImageId,it=instancetype,ist=instanceState,az=instanceAZ,kp=instanceKeyName,priIp=instancePrivateIP,
                        pubIp=instancePublicIP,vpc=instanceVpcId,sub=instanceSubnetId,statereason=instanceStateTransitionReason)
                message={
                        'Subject': {
                            'Data': Subject,
                            'Charset': 'UTF-8'
                        },
                        'Body': {
                            'Html': {
                                'Data': Body,
                                'Charset': 'UTF-8'
                            }
                        }
                    }
                response = ses.send_email(Source=source_Email,Destination={
                        'ToAddresses': [
                            destination_Email,
                        ],
                        'CcAddresses': [
                            cc_Email,
                        ]},Message=message)
                
        print("Manoj")
        print("******************" * 10)